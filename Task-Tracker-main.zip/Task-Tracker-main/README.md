## Task Tracker made using only React.

This application is designed to better organize your life by planning the activities you do every day. </br>

<i> Don't be lazy, add some tasks </i> 😉
</br>
</br>
You can:
- Add tasks.
- Delete tasks.
- Put a reminder.
- Delete a reminder for a task.
</br>
Try it here: https://task-tracker-gabrieldim.netlify.app/
</br>
</br>

> Inspired by: [Brad Traversy](https://github.com/bradtraversy)
